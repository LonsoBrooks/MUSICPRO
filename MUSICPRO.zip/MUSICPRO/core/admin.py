from django.contrib import admin
from .models import Motivo, Usuario

# Register your models here.
admin.site.register(Motivo)
admin.site.register(Usuario)